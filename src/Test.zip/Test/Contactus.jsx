import { useState, useEffect } from "react";

const Contactus = () => {
  const [phy, setPhy] = useState(0);
  const [che, setChe] = useState(0);
  const [math, setMath] = useState(0);
  const [eng, setEng] = useState(0);
  const [hindi, setHindi] = useState(0);

  const [totalMark, setTotalMark] = useState(0);
  const [percentage, setPercentage] = useState(0);
  const [division, setDivision] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    const total = Number(phy) + Number(che) + Number(math) + Number(eng) + Number(hindi);
    setTotalMark(total);
    const per = (total / 500) * 100; // Multiply by 100 to get percentage
    setPercentage(per);
  };

  useEffect(() => {
    let percent;
    if (percentage >= 60) {
      percent = "First division";
    } else if (percentage >= 45) {
      percent = "Second division";
    } else if (percentage >= 33) {
      percent = "Third division";
    } else {
      percent = "Fail";
    }
    setDivision(percent);
  }, [percentage]);

  return (
    <>
      <form onSubmit={handleSubmit} style={{backgroundColor:"lightblue", margin:"100px"}}>
        <label style={{color:"red"}}>
          Phy: <br /><input type="number" value={phy} onChange={(e) => setPhy(e.target.value)} />
        </label>
        <br />
        <label style={{color:"red"}}>
          Che:<br /> <input type="number" value={che} onChange={(e) => setChe(e.target.value)} />
        </label>
        <br />
        <label style={{color:"red"}}>
          Math: <br /><input type="number" value={math} onChange={(e) => setMath(e.target.value)} />
        </label>
        <br />
        <label style={{color:"red"}}>
          Eng: <br /><input type="number" value={eng} onChange={(e) => setEng(e.target.value)} />
        </label>
        <br />
        <label style={{color:"red"}}>
          Hindi: <br /> <input type="number" value={hindi} onChange={(e) => setHindi(e.target.value)} />
        </label>
        <br />
        <button type="submit">Submit</button>
        <h1>Total Mark: {totalMark}</h1>
        <h1>Percentage: {percentage.toFixed(2)}%</h1>
        <h1>Division: {division}</h1>
      </form>
    </>
  );
};

export default Contactus;