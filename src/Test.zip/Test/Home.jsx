
const Home=()=>{
    return(
        <>
        <h1>Home page</h1>
        {/* <div style={{backgroundColor:"yellow", margin:"0px 0px 0px 300px ", width:" 500px", height:"200px", borderRadius:"100%"}}></div>
        <div style={{backgroundColor:"blue", margin:"-150px 0px 0px 370px ", width:" 350px", height:"100px"}}></div>
        <div style={{backgroundColor:"red", margin:"-125px 0px 0px 440px ", width:" 200px", height:"50px", borderRadius:"80%"}}>
            <div style={{margin:"50px", color:"white"}}>CYBROM</div>
        </div> */}

        <div style={{backgroundColor:"yellow", width:"500px", height:"200px",padding:"45px 0px 0px 65px", borderRadius:"100%"}}>
            <div style={{backgroundColor:"blue", width:"350px", height:"100px",padding:"25px 0px 0px 70px"}}>
                <div style={{backgroundColor:"red", width:"200px", height:"50px", borderRadius:"80%"}}>
                    <div style={{padding:"12px 0px 0px 65px", color:"white"}}>CYBROM</div>
                </div>
            </div>
        </div>

    
        </>
    )
}

export default Home;