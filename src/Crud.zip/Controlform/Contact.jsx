
const Contact=()=>{
    return(
        <>
        Contact page
        </>
    )
}

export default Contact;