

const Home=()=>{
    return(
        <>
        <h1>home page</h1>
        </>
    )
}

export default Home;